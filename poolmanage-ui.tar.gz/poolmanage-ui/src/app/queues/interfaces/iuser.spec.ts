import { IUser } from './iuser';

describe('IUser', () => {
  it('should create an instance', () => {
    expect(new IUser()).toBeTruthy();
  });
});
