const usr1 = new userModel({
    fname: 'Sulayman',
    lname: 'Saleem',
    gamesPlayed:10,
    wins: 5,
    losses: 5,
    winstreak: 4,
    
})

const usr2 = new userModel({
    fname: 'Danny',
    lname: 'Lambord',
    gamesPlayed:20,
    wins: 16,
    losses: 4,
    winstreak: 5,
    
})

const usr3 = new userModel({
    fname: 'Danny',
    lname: 'Little',
    gamesPlayed:17,
    wins: 14,
    losses: 3,
    winstreak: 5,
    
})
const usr4 = new userModel({
    fname: 'Ringo',
    lname: 'Star',
    gamesPlayed: 3,
    wins: 0,
    losses: 3,
    winstreak: 0,
    
})
const usr5 = new userModel({
    fname: 'Dimitrios',
    lname: 'Papadeas',
    gamesPlayed: 6,
    wins: 5,
    losses: 1,
    winstreak: 3,
    
})

const usr6 = new userModel({
    fname: 'Thomas',
    lname: 'Gilbert',
    gamesPlayed: 6,
    wins: 5,
    losses: 1,
    winstreak: 3,
    
})

const usr7 = new userModel({
    fname: 'sdfsf',
    lname: 'dfhr',
    gamesPlayed: 6,
    wins: 5,
    losses: 1,
    winstreak: 3,
    
})

const usr8 = new userModel({
    fname: 'Taefa',
    lname: 'agreag',
   
})

const usr9 = new userModel({
    fname: 'sjuyln',
    lname: 'Kqwet',

    
})

const usr10 = new userModel({
    fname: 'mnbbvv',
    lname: 'lkjhfd',   
})
